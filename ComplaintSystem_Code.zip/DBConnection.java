package com.complaint;
import java.sql.*;
public class DBConnection {
    public static Connection getConnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/complaintdb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
                "root","10382");
        }catch(Exception e){ e.printStackTrace(); }
        return null;
    }
}