package com.complaint;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
 protected void doPost(HttpServletRequest req, HttpServletResponse res)
 throws ServletException, IOException {
  String email=req.getParameter("email");
  String password=req.getParameter("password");
  try{
   Connection con=DBConnection.getConnection();
   PreparedStatement ps=con.prepareStatement(
   "SELECT * FROM users WHERE email=? AND password=?");
   ps.setString(1,email);
   ps.setString(2,password);
   ResultSet rs=ps.executeQuery();
   if(rs.next()){
    req.getSession().setAttribute("user",email);
    res.sendRedirect("dashboard.jsp");
   } else res.getWriter().println("Invalid login");
  }catch(Exception e){e.printStackTrace();}
 }
}