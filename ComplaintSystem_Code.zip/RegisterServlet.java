package com.complaint;
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.sql.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
 protected void doPost(HttpServletRequest req, HttpServletResponse res)
 throws ServletException, IOException {
  try{
   Connection con=DBConnection.getConnection();
   PreparedStatement ps=con.prepareStatement(
   "INSERT INTO users(name,email,password) VALUES(?,?,?)");
   ps.setString(1,req.getParameter("name"));
   ps.setString(2,req.getParameter("email"));
   ps.setString(3,req.getParameter("password"));
   ps.executeUpdate();
   res.sendRedirect("login.jsp");
  }catch(Exception e){e.printStackTrace();}
 }
}